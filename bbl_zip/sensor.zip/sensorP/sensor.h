void sensorInit(int D,int C,int E);
int readSensor();
